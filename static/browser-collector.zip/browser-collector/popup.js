document.getElementById('capture').onclick=async()=>{
  const button=document.getElementById('capture'),status=document.getElementById('status');button.disabled=true;
  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},files:['extract.js']});
    const payload=results[0]?.result;if(!payload?.posts?.length)throw new Error('采集没有返回视频，未保存。');
    const text=JSON.stringify(payload);if(text.length>150000)throw new Error('页面数据过大，请缩小可见结果后再采集。');
    const bytes=new TextEncoder().encode(text);let binary='';for(const byte of bytes)binary+=String.fromCharCode(byte);
    await chrome.tabs.create({url:'http://127.0.0.1:8765/browser-import#'+btoa(binary)});
    status.textContent='已打开预览页，请核对后确认收录。';
  }catch(error){status.textContent=error.message||'Chrome未允许读取当前页，请重新点击扩展。';}finally{button.disabled=false;}
};
