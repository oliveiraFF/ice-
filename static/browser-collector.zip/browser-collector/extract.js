/* Read rendered search cards only. No cookies, private app state or network requests. */
(()=>{
  function count(text){const match=String(text||'').replace(/,/g,'').match(/^(?:点赞(?:数)?|播放(?:量|次数)?|评论(?:数)?|收藏(?:数)?)?\s*([\d.]+)\s*(亿|万|[kKwW])?\s*$/);if(!match)return null;const value=Number(match[1])*({亿:1e8,万:1e4,w:1e4,W:1e4,k:1e3,K:1e3}[match[2]]||1);return Number.isFinite(value)&&value>=0&&value<=Number.MAX_SAFE_INTEGER?Math.round(value):null;}
  function collect(doc,href,now=Date.now()/1000){
    const page=new URL(href),match=page.pathname.match(/^\/(?:jingxuan\/)?search\/(.+?)\/?$/);
    if(page.protocol!=='https:'||page.hostname!=='www.douyin.com'||!match)throw new Error('请先在Chrome打开抖音关键词搜索结果页，再采集。');
    const keyword=decodeURIComponent(match[1]).trim();if(!keyword||keyword.length>40)throw new Error('搜索关键词需为1～40字。');
    const posts=[],seen=new Set(),view=doc.defaultView;
    const metric=(card,selectors)=>{const node=card.querySelector(selectors);return node?count(node.getAttribute('aria-label')||node.innerText):null;};
    for(const anchor of doc.querySelectorAll('a[href*="/video/"]')){
      const url=new URL(anchor.getAttribute('href'),page.href),id=url.pathname.match(/^\/video\/(\d+)\/?$/)?.[1];
      if(!id||url.hostname!=='www.douyin.com'||seen.has(id))continue;
      const card=anchor.closest('[data-e2e*="search-card"],li,article')||anchor,rect=card.getBoundingClientRect(),style=view.getComputedStyle(card);
      if(!card.getClientRects().length||rect.bottom<=0||rect.top>=view.innerHeight||style.visibility==='hidden'||style.display==='none')continue;
      const image=card.querySelector('img'),titleNode=card.querySelector('[data-e2e="search-card-desc"],[data-e2e="video-desc"],a[title]');
      const title=(titleNode?.getAttribute('title')||titleNode?.innerText||image?.alt||anchor.getAttribute('aria-label')||anchor.innerText||'无标题视频').trim().slice(0,500);
      const author=(card.querySelector('a[href*="/user/"]')?.innerText||'未知作者').trim().replace(/^@\s*/,'').slice(0,100);
      posts.push({platform:'dy',external_id:id,title,author,url:'https://www.douyin.com/video/'+id,
        cover:(image?.currentSrc||image?.src||'').slice(0,2000)||null,
        plays:metric(card,'[data-e2e="video-play-count"],[aria-label^="播放量"]'),
        likes:metric(card,'[data-e2e="search-card-like"],[data-e2e="video-like"],[aria-label^="点赞"]'),
        comments:metric(card,'[data-e2e="video-comment"],[aria-label^="评论数"]'),
        saves:metric(card,'[data-e2e="video-collect"],[aria-label^="收藏数"]'),
        followers:null,published_at:null,duration:null});
      seen.add(id);if(posts.length===20)break;
    }
    if(!posts.length)throw new Error('没有读到可见视频链接。请确认结果已加载、切换“视频”分类并滚动到结果卡片；遇到登录或验证请本人完成。若仍为0条，当前页面结构暂不支持，未保存数据。');
    return {version:1,keyword,source_url:'https://www.douyin.com/search/'+encodeURIComponent(keyword),captured_at:Math.floor(now),posts};
  }
  if(typeof module!=='undefined')module.exports={collect,count};else return collect(document,location.href);
})();
